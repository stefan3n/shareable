### [< back](../packages.md)

# ArmControl Package

This package contains the following files:

* **HardwareConfiguation.h**
* **Commands.h**
* **Commands.cpp**
* **Communication.h**
* **Communication.cpp**
* **ArmControl.ino**