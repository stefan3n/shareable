### [< back](Technical.md)

# **Setup Guide**

`pip3 install flask` —  required for the web_server component

`pip3 install pyudev` — required for ROS nodes

`pip3 install ultralytics` — required for using YOLO


### **[Ros2](ros2.md)**

### **[GStreamer](gstreamer.md)**
