### [< back](../home.md)

# **Technical  details**

* **[Usage procedure](UsageProcedure.md)**

* **[Setup Guide](SetupGuide.md)**

* **[Car description](CarDescription.md)**

* **[Battery](Battery/Battery.md)**

* **[IMU](IMU.md)**

* **[Jetpack - image reset guie](ResetImage.md)**

